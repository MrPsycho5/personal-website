title: Jakub Papuga | Cheat Sheets
date: 2019-02-08 17:35:03
---
Here is a dump of my cheat sheets that I tend to use to save some of my time.
## 2019
<span style="color:#666">04-2019</span> [Bash script for securing SSH](https://mrpsycho.pl/cheatsheets/Bash-script-for-disabling-password-login/)
<span style="color:#666">04-2019</span> [LVM for Proxmox on OVH/SoYouStart/Kimsufi](https://mrpsycho.pl/cheatsheets/Configuring-Kimsufi-SYS-OVH-drives-to-use-small-root-with-LVM-for-rest/)
<span style="color:#666">04-2019</span> [Hiding Proxmox 5 web interface behind reverse proxy with SSL](https://mrpsycho.pl/cheatsheets/Hide-Proxmox-interface-behind-nginx-reverse-proxy-SSL-VNC/)
<span style="color:#666">03-2019</span> [Configuring Proxmox with one IPv4 on Kimsufi](https://mrpsycho.pl/cheatsheets/Proxmox-on-OVH-Kimsufi-behind-single-IP-NAT/)
<span style="color:#666">03-2019</span> [Tinc Centralized Interconnection](https://mrpsycho.pl/cheatsheets/tinc-centralized-interconnection/)
<span style="color:#666">03-2019</span> [Adding new nodes to Tinc mesh network](https://mrpsycho.pl/cheatsheets/adding-new-nodes-to-tinc-mesh-network/)
<span style="color:#666">02-2019</span> [NGINX Reverse Proxy with caching and SSL](https://mrpsycho.pl/cheatsheets/NGINX-Reverse-Proxy-with-caching-and-SSL/)
<span style="color:#666">02-2019</span> [Configuring Tinc, an encrypted P2P VPN](https://mrpsycho.pl/cheatsheets/how-to-configure-tinc-peer-to-peer-vpn/)

